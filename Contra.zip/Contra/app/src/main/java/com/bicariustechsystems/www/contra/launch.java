package com.bicariustechsystems.www.contra;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class launch extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch);
    }
}
